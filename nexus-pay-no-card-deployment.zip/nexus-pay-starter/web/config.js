// Set this to your Render API URL, e.g. https://nexus-pay-api.onrender.com
// Keep the trailing slash optional. This file contains no secrets.
window.NEXUS_API_BASE = "http://localhost:8080";
