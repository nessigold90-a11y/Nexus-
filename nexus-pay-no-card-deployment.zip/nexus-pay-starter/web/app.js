const API = (window.NEXUS_API_BASE || "http://localhost:8080").replace(/\/$/, "");
const $ = (id) => document.getElementById(id);
function show(id, message, kind="success") {
  $(id).innerHTML = `<div class="${kind}">${message}</div>`;
}
$("customer-form").addEventListener("submit", async (e) => {
  e.preventDefault();
  const data = Object.fromEntries(new FormData(e.target));
  try {
    const r = await fetch(`${API}/v1/demo/customers`, {
      method:"POST", headers:{"Content-Type":"application/json"}, body:JSON.stringify(data)
    });
    const out = await r.json();
    if (!r.ok) throw new Error(out.error || "Could not create profile");
    show("customer-result", `Demo profile created.<br>Customer ID: <code>${out.customerId}</code><br><small>${out.message}</small>`);
  } catch(err) { show("customer-result", err.message, "error"); }
});
$("passkey-btn").addEventListener("click", () => {
  const supported = !!(window.PublicKeyCredential && navigator.credentials);
  show("passkey-result", supported
    ? "This browser supports WebAuthn/passkeys. A production server must issue and verify cryptographic challenges before enrolment or payment."
    : "Passkeys/WebAuthn are not available in this browser or context. Use a supported browser over HTTPS.", supported ? "success" : "error");
});
$("payment-form").addEventListener("submit", async (e) => {
  e.preventDefault();
  const f = Object.fromEntries(new FormData(e.target));
  const amountMinor = Math.round(Number(f.amount) * 100);
  try {
    const r = await fetch(`${API}/v1/pos/payment-intents`, {
      method:"POST", headers:{"Content-Type":"application/json"},
      body:JSON.stringify({
        merchantId:f.merchantId, terminalId:f.terminalId,
        amountMinor, currency:"NGN", description:f.description,
        idempotencyKey:crypto.randomUUID()
      })
    });
    const intent = await r.json();
    if (!r.ok) throw new Error(intent.error || "Could not create payment");
    const confirm = await fetch(`${API}/v1/pos/payment-intents/${intent.id}/confirm-demo`,{method:"POST"});
    const final = await confirm.json();
    show("payment-result",
      `<strong>SIMULATED ${String(final.status).toUpperCase()}</strong><br>Amount: ₦${(final.amountMinor/100).toLocaleString("en-NG",{minimumFractionDigits:2})}<br>Reference: <code>${final.id}</code><br>Provider: ${final.provider}<br><b>No real money was moved.</b>`);
  } catch(err) { show("payment-result", err.message, "error"); }
});
if ("serviceWorker" in navigator) window.addEventListener("load", () => navigator.serviceWorker.register("/sw.js").catch(console.error));
