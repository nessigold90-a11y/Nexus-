# Nexus Pay POS integration contract

A POS vendor should integrate through a native Android SDK or a secure terminal service, not by assuming a browser can access every sensor.

## Suggested transaction lifecycle
1. Terminal authenticates to Nexus Pay using a device-bound credential.
2. Terminal creates a payment intent with amount in minor units (kobo), merchant and terminal IDs, and an idempotency key.
3. Terminal displays the customer consent and amount.
4. A compatible authenticator performs customer verification.
5. Terminal sends the verified, server-verifiable authentication assertion to the backend.
6. Backend validates the assertion and risk rules.
7. Backend calls a licensed payment provider.
8. Backend verifies provider response/webhook and updates the ledger.
9. Terminal polls or receives a signed status event.

Never send raw biometric images to the POS backend. Never let the terminal itself declare a payment successful.
