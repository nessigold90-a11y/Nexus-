# Nexus Pay — no-debit-card development deployment

This deployment path is for a **development/demo sandbox only**. It does not move money, perform real biometric verification, connect bank accounts, or provide production payment processing.

## Target stack
- GitHub: source-code hosting.
- Vercel: static PWA frontend (import the repository and set Root Directory to `web`; Framework Preset `Other`; Build Command empty; Output Directory `.`).
- Render: Node API (Root Directory `api`; Build Command `npm install && npm run build`; Start Command `npm start`). Free web services may sleep when idle and can have limited availability.
- Supabase: managed PostgreSQL for the next development milestone. **The current API still stores demo customers/payment intents in memory and does not yet connect to PostgreSQL.**

Free plans and no-card signup eligibility can change and may vary by country/account. If a provider asks for a payment card, stop and do not enter it; we can choose another provider.

## Deploy sequence
1. Create a GitHub account and a new private repository named `nexus-pay`. Upload/push the contents of this project folder (the files inside `nexus-pay-starter`, not the parent folder).
2. In Vercel, import the GitHub repository. Set Root Directory to `web`, Framework Preset to `Other`, Build Command to blank, and Output Directory to `.`. Deploy the static frontend. Copy its `https://...vercel.app` domain.
3. In Render, create a Web Service from the same GitHub repository. Set Root Directory to `api`, Runtime to Node, Build Command to `npm install && npm run build`, Start Command to `npm start`.
4. Set these Render environment variables for the sandbox only:
   - `NODE_ENV=development`
   - `WEB_ORIGIN=https://YOUR-VERCEL-DOMAIN.vercel.app` (replace with the exact Vercel origin)
   - `ALLOW_DEMO_PAYMENTS=true`
   - `PAYMENT_PROVIDER=mock`
   - `PORT` is supplied by Render; do not hardcode it.
5. Deploy the API and copy its public `https://...onrender.com` URL.
6. Edit `web/config.js` in GitHub and replace `http://localhost:8080` with the Render API URL, without a trailing slash. Commit the change; Vercel should redeploy.
7. Test `/health` on the Render API, then open the Vercel site. A demo payment must visibly say `SIMULATED` and `No real money was moved.`

## Database milestone
Create a Supabase project only if signup is available without a card for your account. Run `db/schema.sql` in Supabase SQL Editor. Store the database connection string only in Render environment variables (never commit it). Before enabling persistence, we must implement parameterised database access, migrations, least-privilege credentials, backups and data-retention controls. The current API does not read/write this database yet.

## Safety / release gate
Do not switch the API to `NODE_ENV=production`: the current API intentionally refuses to start in production because real identity, authorisation and payment adapters do not exist. Do not collect real customer biometrics, BVN/NIN, bank credentials or card details in this demo. A real-money launch requires authorised Nigerian financial partners, legal/regulatory review, audited security controls, operational monitoring and independent testing.

## If a provider requests a card
Do not add one. Stop at that step and tell me which provider and screen is asking; we will adapt the plan.
