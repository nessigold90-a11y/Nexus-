import "dotenv/config";
import express from "express";
import cors from "cors";
import helmet from "helmet";
import { randomUUID } from "node:crypto";
import { z } from "zod";
import { MockPaymentProvider } from "./providers/payment.js";

const app = express();
const port = Number(process.env.PORT || 8080);
const webOrigin = process.env.WEB_ORIGIN || "http://localhost:5173";
const provider = new MockPaymentProvider();
const isProduction = process.env.NODE_ENV === "production";
const demoPaymentsEnabled = process.env.ALLOW_DEMO_PAYMENTS === "true";
if (isProduction) {
  // No production payment adapter or authentication stack exists yet.
  // Fail closed rather than accidentally serving mock payment behaviour.
  throw new Error("Production launch blocked: real payment, identity and authorisation adapters are not implemented");
}

app.use(helmet());
app.use(cors({
  origin: (origin, callback) => {
    // Allow non-browser health checks without Origin; browser requests must match configured origin.
    if (!origin || origin === webOrigin) return callback(null, true);
    return callback(new Error("Origin not allowed"));
  },
  methods: ["GET", "POST"],
  allowedHeaders: ["Content-Type", "Idempotency-Key", "Authorization"]
}));
app.use(express.json({ limit: "32kb" }));

// In-memory demo store. Replace with PostgreSQL repositories before deployment.
const intents = new Map<string, any>();

app.get("/health", (_req, res) => {
  res.json({ ok: true, service: "nexus-pay-api", mode: "development-sandbox" });
});

app.post("/v1/demo/customers", (req, res) => {
  if (isProduction || !demoPaymentsEnabled) {
    return res.status(404).json({ error: "Demo endpoints are disabled" });
  }
  const schema = z.object({
    fullName: z.string().min(2).max(100),
    phone: z.string().min(7).max(20).optional()
  });
  const parsed = schema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: "Invalid customer details" });

  // Demo only: real onboarding requires KYC, consent and verified identity.
  res.status(201).json({
    customerId: randomUUID(),
    ...parsed.data,
    status: "demo_created",
    message: "Demo profile created. No bank account has been linked."
  });
});

app.post("/v1/pos/payment-intents", async (req, res) => {
  if (isProduction || !demoPaymentsEnabled) {
    return res.status(404).json({ error: "Sandbox payment endpoints are disabled" });
  }
  const schema = z.object({
    merchantId: z.string().min(3),
    terminalId: z.string().optional(),
    amountMinor: z.number().int().positive().max(100_000_000),
    currency: z.literal("NGN").default("NGN"),
    description: z.string().max(140).optional(),
    idempotencyKey: z.string().min(12).max(100)
  });
  const parsed = schema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: "Invalid payment request", details: parsed.error.flatten() });

  const existing = [...intents.values()].find(x => x.idempotencyKey === parsed.data.idempotencyKey);
  if (existing) return res.json(existing);

  const id = randomUUID();
  const intent = {
    id,
    ...parsed.data,
    status: "awaiting_customer",
    createdAt: new Date().toISOString(),
    simulated: true
  };
  intents.set(id, intent);
  res.status(201).json(intent);
});

app.post("/v1/pos/payment-intents/:id/confirm-demo", async (req, res) => {
  if (isProduction || !demoPaymentsEnabled) {
    return res.status(404).json({ error: "Sandbox payment endpoints are disabled" });
  }
  const intent = intents.get(req.params.id);
  if (!intent) return res.status(404).json({ error: "Payment intent not found" });
  if (intent.status === "succeeded") return res.json(intent);

  // Demo shortcut ONLY. Production must verify a real customer-authorisation
  // assertion, risk checks and bank/provider authorisation before this step.
  const result = await provider.initiate({
    reference: intent.id,
    amountMinor: intent.amountMinor,
    currency: "NGN",
    narration: intent.description || "Nexus Pay sandbox transaction"
  });
  intent.status = result.status;
  intent.provider = result.provider;
  intent.providerReference = result.providerReference;
  intent.simulated = true;
  intent.updatedAt = new Date().toISOString();
  intents.set(intent.id, intent);
  res.json(intent);
});

app.get("/v1/pos/payment-intents/:id", (req, res) => {
  if (isProduction || !demoPaymentsEnabled) {
    return res.status(404).json({ error: "Sandbox payment endpoints are disabled" });
  }
  const intent = intents.get(req.params.id);
  if (!intent) return res.status(404).json({ error: "Payment intent not found" });
  res.json(intent);
});

// WebAuthn endpoints are intentionally contract placeholders. Implement with
// a maintained WebAuthn server library and persistent, single-use challenges.
app.post("/v1/biometrics/registration-options", (_req, res) => {
  res.status(501).json({
    error: "WebAuthn server integration required",
    guidance: "Generate a random single-use challenge, bind it to the authenticated user and verify the returned attestation."
  });
});

app.post("/v1/biometrics/authentication-options", (_req, res) => {
  res.status(501).json({
    error: "WebAuthn server integration required",
    guidance: "Issue a single-use challenge and verify the assertion signature, origin, RP ID, counter and user verification."
  });
});

app.listen(port, () => {
  console.log(`Nexus Pay API listening on http://localhost:${port}`);
});
