export type PaymentRequest = {
  reference: string;
  amountMinor: number;
  currency: "NGN";
  narration: string;
};

export type PaymentResult = {
  provider: string;
  providerReference: string;
  status: "pending" | "succeeded" | "failed";
  simulated: boolean;
};

export interface PaymentProvider {
  initiate(request: PaymentRequest): Promise<PaymentResult>;
  verify(providerReference: string): Promise<PaymentResult>;
}

// Development only. Replace with a contracted, licensed provider adapter.
// Never use this provider to move real funds.
export class MockPaymentProvider implements PaymentProvider {
  async initiate(request: PaymentRequest): Promise<PaymentResult> {
    return {
      provider: "mock-sandbox",
      providerReference: `MOCK-${request.reference}`,
      status: "succeeded",
      simulated: true
    };
  }

  async verify(providerReference: string): Promise<PaymentResult> {
    return {
      provider: "mock-sandbox",
      providerReference,
      status: "succeeded",
      simulated: true
    };
  }
}
