# Nexus Pay — Web-native biometric payments starter

A runnable development foundation for a cardless, phone-optional payment service:
- Installable Progressive Web App (PWA) for customers and merchants
- Node.js/TypeScript API
- PostgreSQL data model
- WebAuthn registration/authentication hooks (device-dependent; the OS/platform authenticator may use fingerprint, face, PIN or another method)
- Payment-provider adapter with a clearly labelled mock sandbox
- POS integration API contract and example client

## Important boundaries
This is a development starter, **not a live banking product**. It does not connect to Nigerian bank accounts, NIBSS, BVN/NIN databases, or production POS acquiring networks. Real money movement requires contracts, approved APIs, security assessments, regulatory analysis and credentials from licensed providers. Never treat a mock response as a real payment.

Biometric matching and payment authorisation are separate. WebAuthn proves control of an enrolled authenticator; it does not identify a person from a centrally stored fingerprint/face image. The platform never stores raw biometric images or templates.

## Requirements
- Node.js 20+
- npm 10+
- Docker Desktop (for PostgreSQL), or a PostgreSQL 15+ instance

## Run locally
1. Copy `.env.example` to `.env`.
2. Start PostgreSQL: `docker compose up -d db`
3. Install API dependencies: `cd api && npm install`
4. Start API: `npm run dev`
5. In another terminal, serve the PWA: `cd ../web && npx http-server -p 5173`
6. Open `http://localhost:5173`

The API defaults to `http://localhost:8080`. For a local demo, set `ALLOW_DEMO_PAYMENTS=true` in `.env` and set `API_BASE` in `web/app.js` if needed. Demo endpoints are disabled unless explicitly enabled and are always blocked in production.

## Demo flow
- Open the PWA and create a demo customer profile.
- Register a passkey on a compatible device/browser (the device may request fingerprint, face, device PIN or another screen-lock method).
- Open Merchant mode, enter an amount and create a payment intent.
- The demo payment provider returns `sandbox_pending` / `sandbox_succeeded`; this is simulated only.
- In a real deployment, a licensed provider must handle the payment and send a signed webhook. The backend must verify the provider's final status before showing “paid”.

## Audit status
See `docs/AUDIT-STEP-1.md`. The current build is a sandbox only and is not approved for live money movement.

## Production work still required
- Real WebAuthn challenge persistence, origin/RP-ID configuration, attestation policy and signature verification using a maintained WebAuthn server library.
- Customer identity/KYC and bank-account linking via authorised providers.
- Payment initiation/acquiring/settlement agreements and provider adapters.
- Signed webhook verification, reconciliation, refunds and chargeback/dispute workflows.
- Hardware-specific POS SDKs for fingerprint/iris/palm readers; browser PWA APIs cannot access arbitrary POS sensors.
- Threat modelling, penetration testing, privacy impact assessment, data retention controls, disaster recovery and compliance sign-off.

## Layout
- `web/` — installable PWA demo
- `api/` — TypeScript API and sandbox provider
- `db/schema.sql` — initial relational schema
- `pos-sdk/` — example POS integration client
- `docs/` — architecture and API contract

## No-card hosted demo
See [`DEPLOY-NO-CARD.md`](DEPLOY-NO-CARD.md) for the Vercel + Render deployment path. This is sandbox hosting only; the current API does not yet persist to PostgreSQL.
