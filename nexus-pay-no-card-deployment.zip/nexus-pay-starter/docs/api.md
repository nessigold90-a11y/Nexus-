# API outline

Base path: `/v1`

| Method | Endpoint | Purpose |
|---|---|---|
| POST | `/demo/customers` | Create a sandbox-only demo profile |
| POST | `/biometrics/registration-options` | Begin WebAuthn enrolment (placeholder) |
| POST | `/biometrics/authentication-options` | Begin WebAuthn authentication (placeholder) |
| POST | `/pos/payment-intents` | Create a merchant payment intent |
| POST | `/pos/payment-intents/{id}/confirm-demo` | Simulate sandbox payment only |
| GET | `/pos/payment-intents/{id}` | Retrieve payment intent status |

All production payment endpoints need authenticated actors, merchant/terminal authorisation, strict schema validation, idempotency, rate limits, signed webhooks, audit events and provider status verification.
