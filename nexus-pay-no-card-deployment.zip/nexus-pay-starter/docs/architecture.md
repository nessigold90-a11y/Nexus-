# Architecture

```text
Customer PWA / Merchant PWA / Android POS
                 |
          API Gateway + WAF
                 |
   Identity & Consent Service ---- KYC/Identity Provider
                 |
   Authenticator Service --------- WebAuthn / POS sensor adapter
                 |
        Payment Orchestrator
           /           \
 Bank/Payment adapters  Risk & Limits Engine
           \           /
       Ledger + Reconciliation
                 |
       Merchant settlement
```

## Key design decisions
- A biometric modality is performed locally by a supported authenticator or by a certified sensor/provider. The server receives cryptographic proof or a provider verification result, not raw biometric samples.
- WebAuthn/passkeys are suitable for customer presence/user verification on supported devices. They do not guarantee a particular modality: a device can use fingerprint, face, PIN or another local method.
- Phone-free POS use requires a separate enrolled credential or certified biometric terminal flow that can identify the customer without their phone. This is a hardware/provider and governance integration, not a browser-only feature.
- Every payment requires amount-bound consent and bank/provider authorisation.
- Use an append-only ledger and reconciliation process for production.
