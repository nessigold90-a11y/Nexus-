# Nexus Pay — Step 1 technical audit

Audit scope: source files in the initial starter package. This is a static engineering review, not a penetration test, regulatory opinion, or certification.

## Findings

| Severity | Finding | Status / action |
|---|---|---|
| Critical | Demo confirmation can report a simulated payment as successful; no real funds move. | Sandbox only; gated behind `ALLOW_DEMO_PAYMENTS=true` and blocked in production. |
| Critical | No real customer, merchant, terminal authentication or authorisation middleware. | Open blocker before public deployment. |
| Critical | WebAuthn endpoints are placeholders and return HTTP 501. | Production ceremonies and signature verification remain unimplemented. |
| Critical | Mock provider is the only payment provider. | Production startup refuses the mock provider; licensed provider adapter required. |
| High | Profiles and intents are stored in process memory. | PostgreSQL repositories, durable ledger and reconciliation required. |
| High | No signed provider webhook, settlement, refund or dispute implementation. | Open blocker. |
| High | PWA cannot access arbitrary POS fingerprint/iris sensors. | Hardware adapter/native Android POS app required. |
| High | No KYC/AML, consent, limits, fraud/risk engine or privacy operations. | Open blocker; partner and regulatory review required. |
| Medium | CORS was not sufficiently explicit. | Replaced with a configured origin allow-list. |
| Medium | No automated tests, CI, lockfile or observability. | Open blocker. |

## Changes applied in Step 1
- Sandbox endpoints are disabled unless `ALLOW_DEMO_PAYMENTS=true`.
- Sandbox endpoints return 404 in production regardless of the flag.
- Production startup refuses the mock payment provider.
- CORS allows only the configured web origin (plus origin-less non-browser calls).
- `.env.example` documents the explicit demo flag.

## Release decision
**NO-GO for live money movement or public production payment processing.** A static frontend preview can be deployed separately only if clearly marked as a non-financial demo and contains no live payment or identity collection. Do not expose the API as a production payment service in its current state.

## Required gates before live pilot
1. Confirm legal operating model and Nigerian regulatory requirements with qualified counsel.
2. Contract a licensed payment initiation/acquiring provider and obtain sandbox credentials.
3. Implement WebAuthn ceremonies with single-use challenges, strict origin/RP-ID checks, signature verification and persistent credential storage.
4. Implement user, merchant and terminal authentication/authorisation.
5. Implement KYC/consent and a privacy impact assessment for biometric processing under applicable Nigeria data protection rules.
6. Implement a durable double-entry ledger, signed webhooks, reconciliation, idempotency and refund/dispute lifecycle.
7. Integrate approved POS hardware through vendor SDKs/native app and test scanner models.
8. Add automated tests, SAST/dependency scanning, secrets management, monitoring, backups and incident response.
9. Complete independent penetration testing and operational readiness review.
10. Run a closed pilot with approved partners before wider release.

## Deployment prerequisites
A live deployment requires a hosting account/project, domain, managed PostgreSQL, TLS and secrets. Real transactions additionally require partner contracts and credentials. Never share passwords, private keys, API secrets or bank credentials in chat; use the host's secret manager.
